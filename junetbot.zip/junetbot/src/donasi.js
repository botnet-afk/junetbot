const donasi = () => {
	return `

┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 𝗕𝗢𝗦𝗤𝗨𝗘 ❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ 081231971005
┣━⊱ *PULSA*
┣⊱ sama seperti di atas
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY CUBJRNET7*
┗━━━━━━━━━━━━━━━━━━━━

`
}

exports.donasi = donasi